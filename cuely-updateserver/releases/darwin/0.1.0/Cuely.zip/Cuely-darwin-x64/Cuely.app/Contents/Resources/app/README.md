# cuely-searchapp
Electron app for desktop search bar
